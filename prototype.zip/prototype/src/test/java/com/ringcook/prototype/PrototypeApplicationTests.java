package com.ringcook.prototype;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrototypeApplicationTests {

	@Test
	void contextLoads() {
	}

}
